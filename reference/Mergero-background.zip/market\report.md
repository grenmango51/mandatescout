# Market Research & Competitor Analysis: M&A Mandate Origination

**Focus:** Single-advisor origination workflow; complementing MGX Deal Engine  
**Standard:** Grounded in retrieved evidence; explicit separation of facts, claims, inferences, unknowns  
**Scope:** `research/market/` only  

---

## 1. Operating Context & Evidentiary Framework

Mergero is an institutional M&A advisory firm (Zürich, Lugano, Frankfurt, Helsinki). In the challenge brief ([`CHALLENGE_EXTRACT.txt`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/CHALLENGE_EXTRACT.txt)), leadership confirms **18 closed deals in H1 2026**, **€500M+ volume**, **2,000+ verified buyers**, and **€52B+ buyer appetite** on its **MGX Deal Engine**.

Leadership highlights origination as their primary bottleneck:
> *"Today that still happens the traditional way, person by person... Origination itself, however, is still relationship-driven — and that is precisely what limits how fast we can scale across Europe."* (`CHALLENGE_EXTRACT.txt`).

This report evaluates how an individual advisor can originate off-market mandates systematically without enterprise budget. All claims are grounded in primary sources in [`evidence/`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/market/evidence/).

---

## 2. Mergero's Public Workflow & Access Audit

### 2.1 Verified Brief Facts
*   **Metrics:** 18 deals in H1 2026; €500M+ volume; 2,000+ buyers; €52B+ buyer appetite (`CHALLENGE_EXTRACT.txt`).
*   **Key Personnel:** Timo Tontti (Head of Sell-Side; exited factoring firm 2019); Tatu Nordback (Head of Buy-Side); Miiro Nygrén (Associate Director) ([`mergero_about_us.txt`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/market/evidence/mergero_about_us.txt)).
*   **Verified Precedents (2025–2026):** Confirmed Mergero advisory roles:
    1.  *Norband Ltd Oy*: Sold to **Teqnion AB (publ)** (June 2026; ~€4M revenue; RFID/access).
    2.  *Aminopörssi & SinunApteekki*: Investments by **Sponsor Capital** (2026).
    3.  *Suomen Putkisto Palvelu Oy*: Sold to **No Dig Alliance** (**Ambienta** portfolio, 2026).
    4.  *Haapanen Oy*: Sold to **Revivo Group** (**Helix Kapital** portfolio, 2026).

### 2.2 Public Vendor Claims (from `mergero.com`)
*   **Access Audit:** Parent audit tools encountered an interstitial on `/mgx-deal-engine/` and `/for-acquirers/`. Agent direct HTTP extraction succeeded; full responses are saved in [`mergero_mgx_deal_engine.txt`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/market/evidence/mergero_mgx_deal_engine.txt) and [`mergero_for_acquirers.txt`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/market/evidence/mergero_for_acquirers.txt).
*   **Vendor Claims:**
    - MGX operates a "48-hour matching SLA" (mandate share -> matching -> shortlist -> engagement).
    - Outreach volume: *"Mergero runs proprietary outreach across Europe and engages in hundreds of owner discussions per month"*.
    - Mandate structure: Sector, geography, financial brackets (revenue/EBITDA), mandate type, and owner readiness score.

### 2.3 Operational Inferences
*   MGX deal cards map buyer criteria against mandates using relational sector and size tags.
*   Advisor matching pairs algorithmic filtering with partner review (Tontti / Nordback).

### 2.4 Documented Unknowns
*   Internal sourcing tools, database subscriptions, and CRM stack are undisclosed.
*   Conversion funnel metrics (outreach volume to signed mandates) are private.
*   Claims of 3–5 day manual screening time per company lack proof and are excluded.

---

## 3. Commercial Competitor Landscape

Per audit rules, unverified cost estimates and absolute negative claims are excluded. Detailed structured evaluations reside in [`comparison.json`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/market/comparison.json).

| Platform | Pricing Model | Nordic Depth | Verified Capabilities | Weaknesses for Single Advisor |
| :--- | :--- | :--- | :--- | :--- |
| **Inven** | Sales-led enterprise subscription; no public pricing; no free tier | High | Semantic natural language search; founder-owned focus; automated teasers | Inaccessible without enterprise procurement |
| **Grata** | Sales-led enterprise subscription (Datasite); no public pricing | Low (US focus) | Private Company Graph; executive tracking; Grata Deal Network | Heavy US focus; enterprise sales wall |
| **SourceScrub** | Sales-led enterprise subscription (Datasite); no public pricing | Medium | Aggregates 290k+ trade show attendee lists; human data ops | Enterprise pricing; complex interface |
| **Dealsuite** | Paid annual membership for accredited M&A advisory boutiques | High (brokered) | Closed deal-sharing network for anonymized mandates; valuation benchmarks | Only lists already-brokered mandates; cannot originate unmandated targets |
| **Clay** | Freemium ($0 free tier with credits; paid tiers from $149/mo) | Global (APIs) | Multi-provider waterfall data enrichment; automated AI web agent; sequencing | General outbound tool; not designed as an M&A statutory filing database |

---

## 4. Real Public Buyer Theses & Precedent Evidence

Four verified buyer theses usable by an individual advisor are cataloged in [`buyer_evidence.json`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/market/buyer_evidence.json) and backed by raw text in [`evidence/`](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/market/evidence/).

### 4.1 Teqnion AB (publ)
*   **Profile & URL:** Swedish industrial group (`TEQ.ST`). Source: [`https://www.teqnion.se/en/subsidiaries/`](https://www.teqnion.se/en/subsidiaries/) (`#acquisitionstrategy`, retrieved 2026-09-26).
*   **Exact Stated Criteria:** *"Our acquisition criteria are primarily profitability with a profit that can withstand restructuring and integration as well as a stable turnover in the range of SEK 25-150 million."*
*   **Qualitative Fit:** Niche industrial/B2B products; sound management; decentralized ownership; seller relationship extending post-acquisition.
*   **Separation of Group Targets:** Group targets (Net debt / EBITDA < 2.5; EBITA margin > 9%; double EPS every 5 years) apply at group level, not as target company criteria.
*   **Verified Deal Precedent:** Norband Ltd Oy (June 2026; ~€4M revenue; RFID/access; Mergero exclusive advisor).
*   **Unknowns:** Numerical target EBITDA margin %; valuation multiple caps.

### 4.2 Sponsor Capital
*   **Profile & URL:** Finnish PE firm (Funds IV & V, €200M+ each). Source: [`https://www.sponsor.fi/en/toimintatapamme`](https://www.sponsor.fi/en/toimintatapamme) (retrieved 2026-09-26).
*   **Exact Stated Criteria:** *"Our target companies typically have net sales in the range of EUR 15–200 million euros. We also invest in smaller companies, particularly when the goal is significant growth through acquisitions or industry consolidations."*
*   **Qualitative Fit:** Stable, profitable Finnish operations; management partnership; typical 4–7 year holding period.
*   **Verified Deal Precedents:** Aminopörssi & SinunApteekki (2026; sports nutrition/e-commerce; Mergero advised).
*   **Unknowns:** Numerical EBITDA margin % floor; equity ticket distribution.

### 4.3 Indutrade AB (publ)
*   **Profile & URL:** Swedish serial acquirer (`INDT.ST`). Source: [`https://www.indutrade.com/entrepreneurs/how-we-work/`](https://www.indutrade.com/entrepreneurs/how-we-work/) (retrieved 2026-09-26).
*   **Exact Stated Criteria:** *"A typical Indutrade company generates annual sales of between SEK 50-200 million – an amount that enables each MD to maintain overall control and quickly adapt the business to customer requirements."*
*   **Qualitative Fit:** B2B niche leaders; proprietary products or technical trading; stable profitability; decentralized ownership with no exit strategy.
*   **Unknowns:** Target profit margin floor; geographic sub-quotas.

### 4.4 Ambienta / No Dig Alliance
*   **Profile & URL:** Sustainability PE Ambienta / platform No Dig Alliance ([`mergero.com/deals/`](https://mergero.com/deals/)).
*   **Verified Precedent:** Suomen Putkisto Palvelu Oy (February 2026; trenchless piping infrastructure; Mergero advised).
*   **Strategic Thesis:** Buy-and-build consolidation in underground water/wastewater rehabilitation.
*   **Unknowns:** Standalone revenue threshold for add-ons; transaction multiples.

---

## 5. Product Opportunities for an Individual Advisor

### 5.1 Strategic Alignment
A two-sided marketplace is unviable on zero budget. Mergero already owns buyer liquidity (2,000+ verified buyers, €52B+ appetite). The bottleneck is upstream: surfacing uncontacted companies matching active mandates before competing brokers reach them.

### 5.2 Product Concept: "Buyer-Thesis Target Evidence Engine"
An autonomous research workbench matching public buyer theses to verified corporate candidates:
1.  **Public Registry Discovery (PRH / YTJ Base Open Data):**
    *   Validates legal entity (Active Oy status, Business ID).
    *   Extracts registered industry line (TOL / NACE 2008) and domicile.
    *   *(Note: Free financial filtering excluded pending Data Agent audit).*
2.  **Automated Web Evidence Verification:**
    *   Crawls target domains for B2B product lines, client cases, and geographic footprint.
    *   Screens for obvious institutional PE ownership.
3.  **Advisor Pitch Dossier (IC-Grade Target Brief):**
    *   Combines statutory entity details with stated buyer thesis fit.
    *   Generates outreach referencing closed market precedents (e.g., Teqnion/Norband).

### 5.3 Regulatory & Evidentiary Boundaries
1.  **No Unverified Free Financial Filtering:** The product proposal **does not depend on free financial filtering (revenue, EBITDA, balance sheets)** until verified by the Data Research Agent. Free PRH open data confirms entity registration, status, and TOL sector codes. Comprehensive financial statements are treated as an unverified dependency requiring paid registry extract lookup.
2.  **Exclusion of Succession / Owner-Age Inferences:** Public age or incorporation date does not establish transaction willingness. Speculative "succession scoring" is removed. Outreach is anchored strictly on **strategic thesis fit and deal credentials** (e.g., *"We advised Norband on its acquisition by Teqnion and are sourcing comparable B2B niche leaders for active mandates"*).

---

## 6. Summary of Epistemic Status

| Dimension | Verified Fact | Vendor Claim | Inference | Unknown |
| :--- | :--- | :--- | :--- | :--- |
| **Mergero Metrics** | 18 deals H1 2026, €500M+ volume, 2,000+ buyers, €52B appetite (`CHALLENGE_EXTRACT.txt`) | 48-hour matching SLA; hundreds of monthly discussions | Relational database mapping of buyer criteria | Internal conversion rates; screening hours per deal |
| **Competitors** | Clay has freemium tier; Inven/Grata/SourceScrub require sales demos | Inven semantic coverage; Grata intent scoring | Enterprise pricing exceeds single-advisor budget | Exact contract pricing per seat |
| **Buyer Theses** | Teqnion: SEK 25–150M turnover; Sponsor: EUR 15–200M sales; Indutrade: SEK 50–200M sales | "Sound people with soul and heart" (Teqnion) | Serial acquirers maintain steady Nordic mandate demand | Exact target EBITDA % floors; multiple caps |
| **Registry Data** | Business ID, legal name, status, TOL sector available via PRH open data | Complete free financial/EBITDA/shareholder data | Manual filing inspection required for full accounts | PRH free financial API viability (under Data Agent audit) |
