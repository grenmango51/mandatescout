# M&A Mandate Origination: Grounded Workflow Map and Single-Advisor Job Specification

**Author:** Gemini Research Agent (Workflows Lane)  
**Assigned Ownership:** `research/workflows/`  
**Context:** Mergero Mandate Origination Hackathon  
**Primary Brief:** CHALLENGE_EXTRACT.txt  

---

## 1. Context & The Mergero Origination Challenge

According to the challenge brief (*CHALLENGE_EXTRACT.txt*), Mergero is an institutional M&A advisory firm operating across Zürich, Lugano, Frankfurt, and Helsinki. In H1 2026, Mergero completed 18 transactions, with over €500M in closed deal volume, 2,000+ verified buyers, and €52B+ in aggregate buyer appetite. 

Mergero runs two core advisory lines:
1. **Sell-side advisory:** Assisting entrepreneurs and business owners seeking an exit or growth capital.
2. **Buy-side advisory:** Assisting private equity investors, family offices, and strategic acquirers in identifying and executing acquisitions against specific criteria.

While Mergero leverages proprietary technology and its MGX Deal Engine, origination remains "relationship-driven... person by person," creating a scaling bottleneck across European markets (*CHALLENGE_EXTRACT.txt*). The firm seeks scalable mandate origination without proportional headcount expansion.

---

## 2. Pre-Mandate vs. Post-Mandate Workflows

A fundamental operational distinction governs M&A advisory:

*   **Pre-Mandate Work [Synthesis]:** Business development activities conducted *before* an advisory engagement agreement is signed. The firm receives no advisory fees during this phase. All research, screening, and outreach serve one commercial objective: winning an exclusive client mandate.
*   **Post-Mandate Work [Synthesis]:** Execution activities performed *after* an engagement agreement is signed. The advisor executes detailed due diligence, confidential counterpart negotiations, and transaction closing under contract.

### The Target Screener Distinction [Analytical Inference]
Target screening prior to a signed agreement is business development, not transaction execution. Finding acquisition targets does not establish that Mergero has a mandate to buy or sell them. 

For **buy-side origination**, an advisor utilizes a target screener to map unlisted companies matching an investor's criteria. This screener serves exclusively to demonstrate tangible opportunity and sector depth to a prospective buyer. Demonstrating that actionable, off-market opportunities exist persuades the buyer to retain Mergero under a formal search mandate. Conflating pre-mandate target screening with client mandate execution confuses sales origination with delivery.

For **sell-side origination**, pre-mandate screening identifies private companies at structural inflection points. The advisor uses this context to approach owners credibly, winning the mandate to represent them.

---

## 3. Pre-Mandate Origination Workflow Map

The following six-stage workflow maps the journey from market thesis to a signed advisory mandate. Differences between buy-side and sell-side pathways represent our analytical synthesis grounded in industry practice and challenge parameters.

```
[1. Thesis Definition]
       ↓
[2. Target Universe Discovery]
       ↓
[3. Qualification & Pre-Screening]
       ↓
[4. Decision-Maker & Ownership Mapping]
       ↓
[5. Catalyst & Hook Identification]
       ↓
[6. Mandate Presentation & Engagement]
```

### Stage 1: Thesis Definition
*   **Buy-Side [Synthesis]:** Define explicit acquisition parameters (Buy Box) with prospective corporate or financial buyers, including industry focus, operational models, and target geography.
*   **Sell-Side [Synthesis]:** Identify industry sectors experiencing consolidation, regulatory changes, or structural shifts across Nordic and DACH jurisdictions.

### Stage 2: Target Universe Discovery
*   **Vendor Evidence:** Commercial tools index unstructured web data rather than static industry codes. Inven ([https://inven.ai/workflows/deal-sourcing](https://inven.ai/workflows/deal-sourcing)) states: *"Get a ranked, structured list of potential targets across 28M+ companies globally."* Inven's solutions documentation ([https://inven.ai/solutions/investment-banking](https://inven.ai/solutions/investment-banking)) notes that *"Company research is still mostly manual. The best opportunities go to whoever moves first"*.
*   **Buy-Side [Synthesis]:** Query company databases and registries for independent private entities fitting the prospective buyer's Buy Box.
*   **Sell-Side [Synthesis]:** Map regional clusters of private operating companies within active target verticals.

### Stage 3: Qualification & Pre-Screening
*   **Registry Evidence:** Basic entity records are accessible via official open data. The Finnish Patent and Registration Office (PRH) Open Data Service ([https://avoindata.prh.fi/en](https://avoindata.prh.fi/en)) provides APIs to *"retrieve basic details of companies registered at the Finnish Trade Register or of registered notifications, as well as digital financial statement information"*.
*   **Filtering [Synthesis]:** Screen operating status, corporate form, registered business lines, and locations to eliminate out-of-scope entities.

### Stage 4: Decision-Maker & Ownership Mapping
*   **Buy-Side & Sell-Side [Synthesis]:** Identify controlling owners, board directors, and key executives through trade registers and professional directories. Distinguish between founder-owned, family-owned, and institutional/PE-backed entities.

### Stage 5: Catalyst & Hook Identification
*   **Platform Evidence:** Intapp DealCloud ([https://www.intapp.com/dealcloud/solutions/deal-sourcing/](https://www.intapp.com/dealcloud/solutions/deal-sourcing/)) emphasizes that origination workflows help advisors *"Identify deals using market signals and execute targeted outreach."*
*   **Buy-Side [Synthesis]:** Package candidate targets into a thesis validation overview illustrating tangible market opportunities for the buyer.
*   **Sell-Side [Synthesis]:** Identify concrete corporate inflection points—such as leadership expansion, facility additions, or peer consolidation—to provide a legitimate commercial reason for contact rather than speculative outreach.

### Stage 6: Mandate Presentation & Engagement
*   **Buy-Side [Synthesis]:** Present the screened opportunity landscape to prospective buyers to prove origination capability, securing a retained search mandate.
*   **Sell-Side [Synthesis]:** Deliver confidential sector intelligence to the business owner, establishing advisory credibility and negotiating an exclusive engagement agreement.

---

## 4. Empirical Reality vs. Age-Based Sourcing Heuristics

A common assumption in automated deal sourcing is using business owner age as a primary proxy for exit intent. Inven ([https://inven.ai/workflows/deal-sourcing](https://inven.ai/workflows/deal-sourcing)) highlights features to identify generational handover and owners approaching retirement.

### Analytical Evaluation of Age Heuristics [Analytical Inference]
1.  **Readiness Disconnect:** Chronological age does not establish commercial readiness. Many founders retain equity control and board chairmanships while delegating operational leadership to professional managers without initiating an exit.
2.  **Reputational Risk:** Cold outreach referencing an owner's perceived age or retirement timing is invasive, damaging advisor credibility.
3.  **Strategic Focus:** Actionable transaction triggers arise from operational catalysts rather than owner demographics: shareholder capital constraints, partner transitions, and competitive market consolidation.

---

## 5. Information Boundaries: Accessible Data vs. Privileged Judgment

Automated workflows must respect the boundary between public data and privileged information requiring non-disclosure agreements (NDAs) or seasoned human judgment:

| Workflow Dimension | Publicly Accessible (Automated Processing) | Privileged / Confidential (Human Advisor Judgment) |
| :--- | :--- | :--- |
| **Corporate Identity** | Official business IDs, legal names, incorporation dates, and registered addresses via PRH Open Data ([https://avoindata.prh.fi/en](https://avoindata.prh.fi/en)). | Undisclosed subsidiary ownerships, shareholder pacts, voting trust arrangements. |
| **Operational Scope** | Stated products, services, operating locations, and website descriptions. | Customer concentration, supplier dependency, operational bottlenecks. |
| **Financial Position** | Statutory top-line turnover and balance sheets where filed digitally (e.g. iXBRL via PRH). | Normalized EBITDA, owner discretionary expenses, non-recurring adjustments, debt covenants. |
| **Transaction Intent** | Inferred activity signals (job postings, public announcements, peer M&A). | Owner valuation expectations, emotional exit willingness, personal tax considerations. |
| **Relationship Management** | Tracking interaction histories and intermediary touchpoints via CRM systems like DealCloud ([https://www.intapp.com/dealcloud/solutions/deal-sourcing/](https://www.intapp.com/dealcloud/solutions/deal-sourcing/)). | Assessing personal chemistry, negotiation nuances, deal structuring, and fee retainers. |

---

## 6. Competitive Landscape Evaluation

*   **Inven (Inven Oy):** Semantic search engine over private company web domains ([https://inven.ai/workflows/deal-sourcing](https://inven.ai/workflows/deal-sourcing)). Solves unstructured discovery and list compilation. However, web scraping cannot verify true normalized EBITDA or private owner transaction appetite.
*   **DealCloud (Intapp, Inc.):** Institutional relationship and pipeline management platform ([https://www.intapp.com/dealcloud/solutions/deal-sourcing/](https://www.intapp.com/dealcloud/solutions/deal-sourcing/)). Provides centralized tracking across the deal lifecycle. However, it functions as a system of record requiring external data ingestion and substantial integration.
*   **PRH Open Data Service:** Government registry interface ([https://avoindata.prh.fi/en](https://avoindata.prh.fi/en)). Delivers authoritative company verification in Finland free of charge. However, detailed historical financial statements remain behind paid portals (Virre).

---

## 7. Evidence-Based Recommendation: Single-Advisor Job Specification

### Selected Job: Buyer Thesis Opportunity Dossier Generator (Buy-Side Pre-Mandate Screener)

Mergero possesses 2,000+ verified buyers and €52B+ in buyer appetite (*CHALLENGE_EXTRACT.txt*). Inven notes that manual list building impedes advisory velocity and that first movers capture the best opportunities ([https://inven.ai/solutions/investment-banking](https://inven.ai/solutions/investment-banking)). Furthermore, PRH provides free API access for company verification ([https://avoindata.prh.fi/en](https://avoindata.prh.fi/en)).

We recommend building an autonomous, single-user agent tool: the **Buyer Thesis Opportunity Dossier Generator**.

```
[Buyer Buy Box Criteria] 
         ↓
[PRH / Registry & Web Discovery] 
         ↓
[Qualification & Attribute Verification] 
         ↓
[Structured 10-Target Opportunity Dossier] 
         ↓
[Advisor Pitches Prospective Buyer to Secure Mandate]
```

### Operational Specification
1.  **Advisor Input:** The advisor inputs an investment thesis from an institutional or corporate buyer (target vertical, geographic scope, operational attributes).
2.  **Automated Execution:**
    *   Queries public trade register APIs (such as PRH Open Data) and web sources using sector keywords and regional parameters.
    *   Extracts official business IDs, registered addresses, and corporate leadership.
    *   Parses web domains to confirm alignment with thesis criteria.
    *   Generates a structured, evidence-grounded 10-target Opportunity Dossier clearly categorizing verified registry facts, inferred attributes, and unknown financial metrics.
3.  **Commercial Deployment:** The advisor delivers the Opportunity Dossier to a prospective buyer's investment committee to demonstrate that actionable, unlisted targets exist that match their criteria, opening discussions to sign a formal buy-side search mandate.
4.  **Why This Succeeds [Synthesis]:** It transforms abstract pitch conversations into tangible transaction opportunities, directly leveraging Mergero's verified buyer network to win paid buy-side advisory mandates.
