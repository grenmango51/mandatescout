# Verified Research Findings: M&A Mandate Origination

## 1. Decisive Verified Workflow Facts
- **Pre-Mandate Origination vs. Post-Mandate Execution:** Mergero completed 18 deals in H1 2026 with €500M+ volume and 2,000+ buyers, but origination remains relationship-driven and manual ([CHALLENGE_EXTRACT.txt](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/CHALLENGE_EXTRACT.txt)). As proven in [research/workflows/report.md](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/workflows/report.md), pre-mandate target screening serves solely to pitch actionable opportunities to buyers to win advisory search mandates, not execute signed deals.
- **Finnish Statutory Registry Access:** Finnish Patent and Registration Office (PRH) Open Data YTJ-API v3 provides authoritative entity identity (Business ID, Active OY status, TOIMI4 business line, domicile, registered website) via standard TLS without credentials ([PRODUCT_SPEC.md](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/PRODUCT_SPEC.md); [research/workflows/evidence/prh-open-data.html](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/workflows/evidence/prh-open-data.html)).
- **Buyer Acquisition Theses (Direct TLS Retrieval, 2026-09-26):**
  - **Teqnion AB (publ)** (`https://www.teqnion.se/en/subsidiaries/#acquisitionstrategy`, SHA256: `9ed009063d5c67fe...`): Verified turnover SEK 25–150M (~EUR 2.2M–13.2M), profit withstanding restructuring/integration, niche B2B industrial products, seller continuing leadership.
  - **Indutrade AB (publ)** (`https://www.indutrade.com/entrepreneurs/how-we-work/`, SHA256: `46d2f601bff30f47...`): Verified annual sales SEK 50–200M (~EUR 4.4M–17.6M), decentralised management, permanent holding (no exit strategy), niche B2B leadership.
  - **Lifco AB (publ)** (`https://lifco.se/about-lifco/acquisitions/`, SHA256: `49d719a44fae5940...`): Verified documented profitability, niche leadership, no supplier/customer dependency, strict exclusions (weapons, alcohol, tobacco, fossil fuels, FMCG, mining).
  - **Sponsor Capital** (`https://www.sponsor.fi/en/toimintatapamme`, SHA256: `83c8a96ba416ae15...`): Verified net sales EUR 15–200M (smaller for add-ons), Finnish domicile, profitable operations, management partnership (4–7 year holding).
  - **Relais Group Plc** (`https://relais.fi/en/investors/acquisitions/`): TLS certificate expired on host (SSL error). Correctly marked unavailable with zero claimed criteria.

## 2. Decisive Unknowns & Evidentiary Boundaries
- **Financial Thresholds:** Target company normalized EBITDA, EBITDA margins, and multiples are unknown. Free PRH open data excludes full financial accounts. Group financial targets (e.g. Teqnion EBITA > 9%, Lifco 22.4%) apply at parent group level, not as target company entry floors.
- **Owner Intent:** Owner exit readiness cannot be inferred from company age, incorporation date, or director tenure. Speculative succession scoring damages advisor credibility ([research/workflows/report.md](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/research/workflows/report.md)). Transaction willingness is privileged advisor intelligence.

## 3. Buyer Selector Inputs (Frontend/Backend Contract)
All available buyer profiles are codified in [product/data/buyers.json](file:///D:/Hoai%20Anh/Aalto/Hobbies/marketing%20Hack/product/data/buyers.json):
- **Teqnion:** Keywords: `industrial`, `niche`, `components`, `b2b`, `manufacturing`; Industry codes: `25`, `26`, `27`, `28`, `33`.
- **Indutrade:** Keywords: `technical trading`, `industrial`, `flow technology`, `components`, `niche leader`; Industry codes: `46690`, `28990`, `33200`, `71129`.
- **Lifco:** Keywords: `niche leader`, `dental`, `demolition`, `environmental`, `systems`; Industry codes: `32500`, `28920`, `38210`, `28990`.
- **Sponsor Capital:** Keywords: `wellness`, `consumer`, `industrial`, `b2b services`, `software`; Industry codes: `47910`, `62010`, `46900`, `70220`.
- *Notice:* All keywords and industry codes are analyst search suggestions for registry querying, NOT buyer-confirmed parameters.

## 4. Flagged Research Errors Affecting Product
1. **Silent Fallback to Hardcoded Snippets:** `research/data/fetch_sources.py` silently caught fetch failures and substituted pre-baked text with status 0, disguising failed HTTP scrapes as verified evidence.
2. **Conflating Group Targets with Target Criteria:** Early research drafts treated Teqnion's corporate financial targets (EBITA > 9%, debt/EBITDA < 2.5) as target screening floors. Primary text proves target criterion is qualitative profit durability and SEK 25–150M turnover.
3. **Outdated Taxonomy Labels:** `research/data` scripts labeled PRH business lines as TOL2008 without noting PRH's active 2026 TOIMI4 taxonomy update.
4. **Unverified Relais Scrapes:** Previous reports listed Relais criteria as live-fetched despite `relais.fi` serving an expired SSL certificate under strict TLS verification.
